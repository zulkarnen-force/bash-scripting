PROD_SERVER=""

if [ "$TEST" = "true" ]; then
    echo "Production server"
else 
    echo "Development server"
fi