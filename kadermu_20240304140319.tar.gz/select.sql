SELECT * FROM tbl_ref_jenis_dokumen;
